<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.create'); ?>
        <?php $__env->slot('title','Criar Medição'); ?>
        <?php $__env->slot('back', url()->previous()); ?>
        <?php $__env->slot('store', route('measurements.store')); ?>
        <?php $__env->slot('form'); ?>
            <?php echo $__env->make('measurements.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->endSlot(); ?>
        
    <?php if (isset($__componentOriginal10b55bc55c356fbe160fc7a041fd7ad9be49a817)): ?>
<?php $component = $__componentOriginal10b55bc55c356fbe160fc7a041fd7ad9be49a817; ?>
<?php unset($__componentOriginal10b55bc55c356fbe160fc7a041fd7ad9be49a817); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/measurements/create.blade.php ENDPATH**/ ?>