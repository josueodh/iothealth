<div class="row">
    <div class="col-12 form-group">
        <label for="temperature">Temperatura</label>
        <div class="input-group mb-3">
            <input type="number" id="temperature" name="temperature" required 
                class="form-control" step="0.1" min="30" max="44" value="<?php echo e(old('temperature', $measurement->temperature)); ?>">
            <div class="input-group-append">
              <span class="input-group-text">°C</span>
            </div>
        </div>
    </div>
    <div class="col-12 form-group">
        <label for="heart_rate">Frequência Cardiaca</label>
        <div class="input-group mb-3">
            <input type="number" id="heart_rate" name="heart_rate" required 
                class="form-control" step="1"  value="<?php echo e(old('heart_rate', $measurement->heart_rate)); ?>">
            <div class="input-group-append">
              <span class="input-group-text">bpm</span>
            </div>
        </div>
    </div>
    <div class="col-12 form-group">
        <label for="sleep">Horas de Sono</label>
        <input type="time" id="sleep" name="sleep" required class="form-control"  value="<?php echo e(old('sleep', $measurement->sleep)); ?>">
    </div>
    <div class="col-12 form-group">
        <label for="arterial_frequency">Frequência Arterial</label>
        <div class="input-group mb-3">
            <input type="text" id="arterial_frequency" name="arterial_frequency" required 
                class="form-control" value="<?php echo e(old('arterial_frequency', $measurement->arterial_frequency)); ?>">
            <div class="input-group-append">
              <span class="input-group-text">mmhg</span>
            </div>
        </div>
    </div>
    <div class="col-12 form-group">
        <label for="time">Horario e dia da coleta</label>
        <?php if(!Route::is('measurements.create')): ?>
            <input type="datetime-local" id="time" name="time" required class="form-control"  value="<?php echo e(old('time', date('Y-m-d\TH:i:s', strtotime($measurement->time)))); ?>">
        <?php else: ?>
            <input type="datetime-local" id="time" name="time" required class="form-control"  value="<?php echo e(old('time')); ?>">
        <?php endif; ?>
    </div>
    <div class="col-12 form-group">
        <label for="patient_id">Paciente</label>
        <select name="patient_id" id="patient_id" class="form-control select2 <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  value="<?php echo e(old('patient_id', $measurement->patient_id)); ?>">
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script>
        $('.select2').select2({
            placeholder:'Selecione um Paciente',
            allowClear: true,
        });
        $('select[value]').each(function () {
            $(this).val($(this).attr('value'));
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/measurements/form.blade.php ENDPATH**/ ?>