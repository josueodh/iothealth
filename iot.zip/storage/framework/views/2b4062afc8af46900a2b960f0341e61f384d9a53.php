<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.index'); ?>
        <?php $__env->slot('title','Sono / Passos'); ?>
        <?php $__env->slot('create', route('diaries.create')); ?>
        <?php $__env->slot('header'); ?>
            <th>Paciente</th>
            <th>Data</th>
            <th>Sono</th>
            <th>Passos</th>
            <th></th>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('body'); ?>
            <?php $__empty_1 = true; $__currentLoopData = $diaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($diary->patient->name); ?></td>
                    <td><?php echo e(date('d/m/Y',strtotime($diary->date))); ?></td>
                    <td><?php echo e(date('H:m',strtotime($diary->sleep))); ?></td>
                    <td><?php echo e($diary->walk); ?></td>
                    <td class="button-index">
                        <a href="<?php echo e(route('diaries.edit', $diary->id)); ?>" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                        <form class="form-delete" action="<?php echo e(route('diaries.destroy', $diary->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
                        </form>
												
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Nenhuma medição encontrada</td>
                </tr>
            <?php endif; ?>
        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalb6b957b1b6945f733b45f8045bb0d4656a2ac6f4)): ?>
<?php $component = $__componentOriginalb6b957b1b6945f733b45f8045bb0d4656a2ac6f4; ?>
<?php unset($__componentOriginalb6b957b1b6945f733b45f8045bb0d4656a2ac6f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/components/dataTable.js')); ?>"></script>            
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/diaries/index.blade.php ENDPATH**/ ?>