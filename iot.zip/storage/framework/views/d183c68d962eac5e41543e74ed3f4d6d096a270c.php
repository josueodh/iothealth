<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 text-center">
        <img src="<?php echo e(asset('/img/logo.png')); ?>" class="img-fluid img-dashboard">
        <h2 class="mt-5">Bem vindo, <?php echo e(Auth::user()->name); ?></b></h2>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/home.blade.php ENDPATH**/ ?>