<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.show'); ?>
        <?php $__env->slot('title','Detalhes  da medição'); ?>
        <?php $__env->slot('back', url()->previous()); ?>
        <?php $__env->slot('form'); ?>
            <?php echo $__env->make('measurements.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf77674f9990f76cbf0cadf0ef1917f413ae61f4a)): ?>
<?php $component = $__componentOriginalf77674f9990f76cbf0cadf0ef1917f413ae61f4a; ?>
<?php unset($__componentOriginalf77674f9990f76cbf0cadf0ef1917f413ae61f4a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('.form-control').attr('disabled',true);
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/measurements/show.blade.php ENDPATH**/ ?>