<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.edit'); ?>
        <?php $__env->slot('title','Editar medição'); ?>
        <?php $__env->slot('back', url()->previous()); ?>
        <?php $__env->slot('update', route('diaries.update', $diary->id)); ?>
        <?php $__env->slot('form'); ?>
            <?php echo $__env->make('diaries.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal536d2eec6142527b426d1efeff18d81146a94301)): ?>
<?php $component = $__componentOriginal536d2eec6142527b426d1efeff18d81146a94301; ?>
<?php unset($__componentOriginal536d2eec6142527b426d1efeff18d81146a94301); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/diaries/edit.blade.php ENDPATH**/ ?>