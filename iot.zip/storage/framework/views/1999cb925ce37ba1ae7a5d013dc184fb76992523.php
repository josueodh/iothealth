<?php $__env->startSection('content'); ?>
<div id="app" class="login-box">
    <div class="login-logo">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo Iot Health" class="img-fluid">
    </div>
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Faça o login para iniciar sua sessão</p>
            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input placeholder="E-mail" type="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" name="email" autocomplete="username"
                        value="<?php echo e(old('email')); ?>" required autofocus>
                    <div class="input-group-append">
                        <span class="input-group-text">
                            <i class="fas fa-envelope"></i>
                        </span>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="input-group mb-3">
                    <input placeholder="Senha" type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>"
                        name="password" autocomplete="current-password" required>
                    <div class="input-group-append">
                        <span class="input-group-text">
                            <i class="fas fa-lock"></i>
                        </span>
                    </div>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                <?php echo e(old('remember') ? 'checked' : ''); ?>>

                            <label class="form-check-label" for="remember">
                                Lembre-me
                            </label>
                        </div>
                    </div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-dark btn-block">Login</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/auth/login.blade.php ENDPATH**/ ?>