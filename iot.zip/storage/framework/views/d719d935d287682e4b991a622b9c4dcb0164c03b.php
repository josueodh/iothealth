<div class="row">
    <div class="col-12 form-group">
        <label for="date">Data</label>
        <input type="date" id="date" name="date" class="form-control" required value="<?php echo e(old('date', $diary->date)); ?>">
    </div>
    <div class="col-12 form-group">
        <label for="walk">Passos</label>
        <input type="text" name="walk" id="walk" class="form-control"required value="<?php echo e(old('walk', $diary->walk)); ?>">
    </div>
    <div class="col-12 form-group">
        <label for="sleep">Sono</label>
        <input type="time" name="sleep" id="sleep" class="form-control" required value="<?php echo e(old('sleep', $diary->sleep)); ?>">
    </div>
    <div class="col-12 form-group">
        <label for="patient">Paciente</label>
        <select class="form-control select2" required name="patient_id" value="<?php echo e(old('patient_id', $diary->patient_id)); ?>">
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
          $(function() {
                $('.select2').select2();
            });
        $('select[value]').each(function () {
            $(this).val($(this).attr('value'));
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/diaries/form.blade.php ENDPATH**/ ?>