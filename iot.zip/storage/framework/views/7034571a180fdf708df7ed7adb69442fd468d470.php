<?php if(session('success')): ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
             Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Ação concluida com sucesso!',
                showConfirmButton: false,
                timer: 1500
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/josueodh/Área de Trabalho/faculdade/bolsa/resources/views/includes/success.blade.php ENDPATH**/ ?>